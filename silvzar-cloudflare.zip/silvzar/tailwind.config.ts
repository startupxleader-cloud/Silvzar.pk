import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: { obsidian: "#08090B", graphite: "#202226", silver: "#C7C9CE", pearl: "#F4F1EA", champagne: "#B59A68" },
      fontFamily: { serif: ["var(--font-serif)", "serif"], sans: ["var(--font-sans)", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
export default config;
