"use client";
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center px-5 text-center">
      <h1 className="font-serif text-4xl text-pearl">Something went wrong</h1>
      <button onClick={reset} className="mt-8 text-xs uppercase tracking-[0.3em] text-champagne">Try again</button>
    </div>
  );
}
