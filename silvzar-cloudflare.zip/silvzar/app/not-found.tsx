import Link from "next/link";
export default function NotFound() {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center px-5 text-center">
      <h1 className="font-serif text-5xl text-pearl">Not found</h1>
      <Link href="/" className="mt-8 text-xs uppercase tracking-[0.3em] text-champagne">Back home</Link>
    </div>
  );
}
