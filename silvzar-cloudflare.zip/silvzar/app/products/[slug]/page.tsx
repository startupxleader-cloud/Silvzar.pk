import type { Metadata } from "next";
import { notFound } from "next/navigation";
import AddToCart from "@/components/AddToCart";
import Gallery from "@/components/Gallery";
import { getProduct } from "@/lib/data";
import { pkr } from "@/lib/format";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProduct((await params).slug);
  if (!p) return { title: "Not found" };
  return { title: p.name, description: p.description?.slice(0, 155), openGraph: { images: p.product_images[0] ? [p.product_images[0].url] : [] } };
}

export default async function ProductPage({ params }: Props) {
  const p = await getProduct((await params).slug);
  if (!p) notFound();
  return (
    <div className="mx-auto grid max-w-6xl gap-10 px-5 pb-24 pt-28 md:grid-cols-2">
      <Gallery images={p.product_images} name={p.name} />
      <div className="md:pt-6">
        {p.category && <p className="text-xs uppercase tracking-[0.4em] text-champagne">{p.category}</p>}
        <h1 className="mt-3 font-serif text-4xl text-pearl">{p.name}</h1>
        <p className="mt-4 font-serif text-2xl text-silver">{pkr(p.price_pkr)}</p>
        <p className="mt-6 whitespace-pre-line leading-8 text-silver/80">{p.description}</p>
        <p className="mt-6 text-xs text-silver/60">{p.stock > 0 ? (p.stock <= 5 ? `Only ${p.stock} left` : "In stock") : "Currently sold out"} · Pay by bank or wallet transfer</p>
        <div className="mt-8"><AddToCart p={p} /></div>
      </div>
    </div>
  );
}
