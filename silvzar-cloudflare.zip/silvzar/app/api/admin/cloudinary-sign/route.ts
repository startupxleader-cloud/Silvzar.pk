import crypto from "node:crypto";
import { supabaseServer } from "@/lib/supabase/server";

// Admin-only: returns a short-lived signature so the browser can upload straight to Cloudinary.
// The API secret never leaves the server.
export async function POST() {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  const { data: ok } = user ? await sb.rpc("is_admin") : { data: false };
  if (!user || ok !== true) return Response.json({ error: "Forbidden" }, { status: 403 });

  const cloud = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME, key = process.env.CLOUDINARY_API_KEY, secret = process.env.CLOUDINARY_API_SECRET;
  if (!cloud || !key || !secret) return Response.json({ error: "Cloudinary is not configured on the server." }, { status: 500 });

  const timestamp = Math.floor(Date.now() / 1000);
  const folder = "silvzar/products";
  const allowed = "jpg,jpeg,png,webp,heic";
  const signature = crypto.createHash("sha1").update(`allowed_formats=${allowed}&folder=${folder}&timestamp=${timestamp}${secret}`).digest("hex");
  return Response.json({ cloud, key, timestamp, folder, allowed, signature }, { headers: { "Cache-Control": "no-store" } });
}
