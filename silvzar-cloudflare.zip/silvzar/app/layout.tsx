import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Inter } from "next/font/google";
import "./globals.css";
import CartProvider from "@/components/CartProvider";
import Header from "@/components/Header";
import FloatingDock from "@/components/FloatingDock";
import Chrome from "@/components/Chrome";

const serif = Cormorant_Garamond({ subsets: ["latin"], weight: ["300", "400", "500", "600"], variable: "--font-serif" });
const sans = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://silvzar.com"),
  title: { default: "SILVZAR | Premium Jewellery Pakistan", template: "%s | SILVZAR" },
  description: "Premium stainless steel and silver-tone jewellery, designed for Pakistan.",
  openGraph: { siteName: "SILVZAR", type: "website", locale: "en_PK" },
};
export const viewport: Viewport = { themeColor: "#08090B", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable}`}>
      <body className="min-h-svh bg-obsidian">
        <CartProvider>
          <Chrome><Header /></Chrome>
          <main>{children}</main>
          <Chrome><footer className="border-t border-white/5 px-5 py-14 text-center">
            <p className="font-serif text-xl tracking-[0.5em] text-silver">SILVZAR</p>
            <p className="mt-3 text-xs text-silver/50">© {new Date().getFullYear()} SILVZAR. Crafted for Pakistan.</p>
          </footer></Chrome>
          <Chrome><FloatingDock /></Chrome>
        </CartProvider>
      </body>
    </html>
  );
}
