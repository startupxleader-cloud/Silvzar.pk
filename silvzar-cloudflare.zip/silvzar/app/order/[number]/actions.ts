"use server";
import { revalidatePath } from "next/cache";
import { db } from "@/lib/data";

export type RefState = { ok: boolean; message: string } | null;

export async function submitReference(_prev: RefState, f: FormData): Promise<RefState> {
  const number = String(f.get("number") ?? ""), token = String(f.get("token") ?? ""), ref = String(f.get("reference") ?? "");
  const { error } = await db().rpc("submit_payment_reference", { p_order_number: number, p_token: token, p_reference: ref });
  if (error) {
    if (error.message === "INVALID:reference") return { ok: false, message: "Enter the transaction ID or reference (4–60 letters/numbers)." };
    if (error.message === "NOT_ALLOWED") return { ok: false, message: "Payment can no longer be updated for this order." };
    return { ok: false, message: "We couldn't save that. Please try again." };
  }
  revalidatePath(`/order/${number}`);
  return { ok: true, message: "Thank you. We'll verify your payment and update this page." };
}
