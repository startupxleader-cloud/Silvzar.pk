import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PaymentRefForm from "@/components/PaymentRefForm";
import { getOrder, getSettings } from "@/lib/data";
import { pkr } from "@/lib/format";

export const metadata: Metadata = { title: "Your order", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

const statusLabel: Record<string, string> = { pending: "Received", confirmed: "Confirmed", shipped: "Shipped", delivered: "Delivered", cancelled: "Cancelled" };
const payLabel: Record<string, string> = {
  awaiting_payment: "Awaiting your payment", awaiting_verification: "Payment submitted, awaiting verification",
  verified: "Payment verified", rejected: "Payment could not be verified. Please resubmit the reference.",
};

export default async function OrderPage({ params, searchParams }: { params: Promise<{ number: string }>; searchParams: Promise<{ t?: string }> }) {
  const { number } = await params;
  const { t = "" } = await searchParams;
  const o = await getOrder(number, t);
  if (!o) notFound();
  const settings = o.payment_method === "bank_transfer" ? await getSettings() : null;
  const canPay = o.payment_method === "bank_transfer" && o.payment_status !== "verified" && o.status !== "cancelled";
  return (
    <div className="mx-auto max-w-2xl px-5 pb-24 pt-28">
      <p className="text-center text-xs uppercase tracking-[0.4em] text-champagne">Thank you, {o.customer_name.split(" ")[0]}</p>
      <h1 className="mt-3 text-center font-serif text-4xl text-pearl">Order {o.order_number}</h1>
      <p className="mt-2 text-center text-sm text-silver/60">Save this page's link. It is the only way to check your order.</p>

      <div className="mt-10 grid grid-cols-2 gap-4 text-sm">
        <div className="border border-white/10 p-4"><p className="text-silver/60">Order status</p><p className="mt-1 text-pearl">{statusLabel[o.status] ?? o.status}</p></div>
        <div className="border border-white/10 p-4"><p className="text-silver/60">Payment</p><p className="mt-1 text-pearl">{payLabel[o.payment_status] ?? o.payment_status}</p></div>
      </div>

      <div className="mt-8 space-y-3 border border-white/10 p-6 text-sm">
        {o.items.map((i, k) => <div key={k} className="flex justify-between gap-4"><span>{i.name} × {i.qty}</span><span className="text-silver">{pkr(i.unit_price_pkr * i.qty)}</span></div>)}
        <div className="flex justify-between border-t border-white/10 pt-3"><span className="text-silver">Subtotal</span><span>{pkr(o.subtotal_pkr)}</span></div>
        <div className="flex justify-between"><span className="text-silver">Shipping</span><span>{o.shipping_pkr === 0 ? "Free" : pkr(o.shipping_pkr)}</span></div>
        <div className="flex justify-between font-serif text-2xl"><span>Total</span><span>{pkr(o.total_pkr)}</span></div>
        <p className="pt-2 text-silver/60">Delivering to {o.address}, {o.city}</p>
      </div>

      {canPay && settings && (
        <div className="mt-8 border border-champagne/40 p-6">
          <h2 className="font-serif text-2xl text-pearl">Complete your payment</h2>
          <p className="mt-3 whitespace-pre-line text-sm leading-7 text-silver/80">{settings.payment_instructions}</p>
          <p className="mt-3 text-sm text-silver">Amount: <span className="text-champagne">{pkr(o.total_pkr)}</span></p>
          {o.payment_reference && <p className="mt-2 text-sm text-silver/60">Reference on file: {o.payment_reference}</p>}
          <PaymentRefForm number={o.order_number} token={t} />
        </div>
      )}
      <div className="mt-10 text-center"><Link href="/collections/all" className="text-xs uppercase tracking-[0.3em] text-champagne">Continue shopping</Link></div>
    </div>
  );
}
