import type { Metadata } from "next";
import ProductCard from "@/components/ProductCard";
import { getCategories, getCollections, getProducts, type Sort } from "@/lib/data";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ q?: string; sort?: string; category?: string }> };
const sorts: Record<Sort, string> = { new: "Newest", price_asc: "Price: low to high", price_desc: "Price: high to low" };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const name = slug === "all" ? "All Jewellery" : (await getCollections()).find((c) => c.slug === slug)?.name ?? "Collection";
  return { title: name };
}

export default async function CollectionPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const sp = await searchParams;
  const sort: Sort = sp.sort && sp.sort in sorts ? (sp.sort as Sort) : "new";
  const q = sp.q?.slice(0, 60) ?? "";
  const category = sp.category?.slice(0, 60) ?? "";
  const [products, collections, categories] = await Promise.all([
    getProducts({ collection: slug, q, category: category || undefined, sort }), getCollections(), getCategories(),
  ]);
  const current = collections.find((c) => c.slug === slug);
  const field = "h-11 rounded-full border border-white/15 bg-graphite px-4 text-sm text-pearl outline-none focus:border-champagne";
  return (
    <div className="mx-auto max-w-7xl px-5 pb-24 pt-32">
      <h1 className="text-center font-serif text-5xl text-pearl">{slug === "all" ? "All Jewellery" : current?.name ?? "Collection"}</h1>
      {current?.description && <p className="mx-auto mt-4 max-w-md text-center text-sm text-silver/70">{current.description}</p>}

      <form method="get" className="mx-auto mt-10 flex max-w-3xl flex-wrap justify-center gap-3">
        <input name="q" defaultValue={q} placeholder="Search jewellery" aria-label="Search" maxLength={60} className={`${field} w-full sm:w-64`} />
        <select name="category" defaultValue={category} aria-label="Category" className={field}>
          <option value="">All categories</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select name="sort" defaultValue={sort} aria-label="Sort" className={field}>
          {Object.entries(sorts).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <button className="h-11 rounded-full bg-silver px-8 text-xs font-medium uppercase tracking-[0.25em] text-obsidian">Apply</button>
      </form>

      {products.length === 0 ? (
        <p className="mt-20 text-center text-silver/60">No pieces match. Try a different search.</p>
      ) : (
        <div className="mt-14 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
          {products.map((p) => <ProductCard key={p.id} p={p} />)}
        </div>
      )}
    </div>
  );
}
