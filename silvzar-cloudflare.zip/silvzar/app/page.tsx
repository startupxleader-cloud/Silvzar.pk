import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import { getCollections, getProducts } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [products, collections] = await Promise.all([getProducts({ limit: 8 }), getCollections()]);
  return (
    <>
      <section className="relative flex min-h-svh items-center justify-center overflow-hidden px-5">
        <div className="drift absolute -left-1/4 top-0 h-[70vh] w-[70vh] rounded-full bg-silver/10 blur-[110px]" />
        <div className="drift absolute -right-1/4 bottom-0 h-[60vh] w-[60vh] rounded-full bg-champagne/10 blur-[110px]" style={{ animationDelay: "-8s" }} />
        <div className="spin-slow absolute h-[min(90vw,640px)] w-[min(90vw,640px)] rounded-full border border-silver/10">
          <span className="absolute left-1/2 top-0 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-silver shadow-[0_0_24px_6px_rgba(199,201,206,.5)]" />
        </div>
        <div className="spin-slow absolute h-[min(65vw,440px)] w-[min(65vw,440px)] rounded-full border border-champagne/10" style={{ animationDirection: "reverse", animationDuration: "40s" }} />
        <div className="rise relative text-center">
          <p className="mb-6 text-xs uppercase tracking-[0.6em] text-champagne">Pakistan · Est. 2025</p>
          <h1 className="silver-text font-serif text-6xl font-light tracking-[0.25em] sm:text-8xl">SILVZAR</h1>
          <p className="mx-auto mt-6 max-w-md font-serif text-xl italic text-silver/80">Light, worn close. Jewellery made to be noticed quietly.</p>
          <Link href="/collections/all" className="mt-10 inline-block rounded-full border border-silver/40 px-10 py-3 text-xs uppercase tracking-[0.35em] text-pearl transition hover:border-champagne hover:text-champagne">Enter the collection</Link>
        </div>
        <div className="absolute bottom-8 left-1/2 h-12 w-px -translate-x-1/2 bg-gradient-to-b from-silver/60 to-transparent" />
      </section>

      <section className="mx-auto max-w-7xl px-5 py-24">
        <Reveal><h2 className="text-center font-serif text-4xl text-pearl sm:text-5xl">The Exclusive Collection</h2></Reveal>
        <Reveal delay={150}><p className="mx-auto mt-4 max-w-md text-center text-sm text-silver/70">Newest arrivals, each piece in limited stock.</p></Reveal>
        {products.length === 0 ? (
          <p className="mt-16 text-center text-silver/60">Pieces are being prepared. Please check back soon.</p>
        ) : (
          <div className="mt-14 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
            {products.map((p, i) => <Reveal key={p.id} delay={(i % 4) * 100}><ProductCard p={p} /></Reveal>)}
          </div>
        )}
      </section>

      {collections.length > 0 && (
        <section className="mx-auto grid max-w-7xl gap-4 px-5 pb-24 md:grid-cols-2">
          {collections.map((c) => (
            <Reveal key={c.id}>
              <Link href={`/collections/${c.slug}`} className="group relative flex h-64 flex-col justify-end overflow-hidden border border-white/10 bg-gradient-to-br from-graphite to-obsidian p-8">
                <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-silver/10 blur-3xl transition duration-700 group-hover:bg-champagne/20" />
                <h3 className="font-serif text-3xl text-pearl">{c.name}</h3>
                <p className="mt-1 text-sm text-silver/70">{c.description}</p>
                <span className="mt-4 text-xs uppercase tracking-[0.3em] text-champagne">Explore →</span>
              </Link>
            </Reveal>
          ))}
        </section>
      )}

      <section id="story" className="mx-auto max-w-2xl scroll-mt-20 px-5 pb-28 text-center">
        <Reveal><h2 className="font-serif text-4xl text-pearl">Our Story</h2></Reveal>
        <Reveal delay={150}><p className="mt-6 leading-8 text-silver/80">SILVZAR creates refined, durable jewellery for everyday elegance. Placeholder copy: replace this with your brand story.</p></Reveal>
      </section>
    </>
  );
}
