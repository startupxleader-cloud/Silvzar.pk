"use client";
import { useActionState } from "react";
import { signIn } from "./actions";

export default function LoginForm() {
  const [state, action, pending] = useActionState(signIn, null);
  const f = "w-full rounded border border-white/15 bg-graphite px-4 py-3 text-pearl outline-none focus:border-champagne";
  return (
    <form action={action} className="mt-8 space-y-4">
      <input name="email" type="email" required autoComplete="username" placeholder="Email" className={f} />
      <input name="password" type="password" required autoComplete="current-password" placeholder="Password" className={f} />
      {state?.error && <p role="alert" className="text-sm text-red-300">{state.error}</p>}
      <button disabled={pending} className="w-full rounded-full bg-silver py-3 text-xs font-medium uppercase tracking-[0.3em] text-obsidian disabled:opacity-50">{pending ? "Signing in…" : "Sign in"}</button>
    </form>
  );
}
