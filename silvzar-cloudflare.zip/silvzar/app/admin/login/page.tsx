import LoginForm from "./LoginForm";

export default async function Login({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  const { e } = await searchParams;
  return (
    <div className="mx-auto flex min-h-svh max-w-sm flex-col justify-center px-5">
      <p className="text-center font-serif text-2xl tracking-[0.45em]">SILVZAR</p>
      <p className="mt-2 text-center text-xs uppercase tracking-[0.3em] text-champagne">Admin</p>
      {e && <p className="mt-6 text-center text-sm text-red-300">This account is not authorized.</p>}
      <LoginForm />
    </div>
  );
}
