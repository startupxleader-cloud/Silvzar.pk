"use server";
import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

export async function signIn(_prev: { error?: string } | null, f: FormData) {
  const email = String(f.get("email") ?? "").trim().slice(0, 200);
  const password = String(f.get("password") ?? "").slice(0, 200);
  const sb = await supabaseServer();
  const { error } = await sb.auth.signInWithPassword({ email, password });
  if (error) return { error: "Invalid email or password." };
  const { data: ok } = await sb.rpc("is_admin");
  if (ok !== true) { await sb.auth.signOut(); return { error: "This account is not authorized." }; }
  redirect("/admin");
}

export async function signOut() {
  const sb = await supabaseServer();
  await sb.auth.signOut();
  redirect("/admin/login");
}
