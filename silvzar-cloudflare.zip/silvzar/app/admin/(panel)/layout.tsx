import Link from "next/link";
import { requireAdmin } from "@/lib/admin";
import { signOut } from "../login/actions";

export default async function Panel({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  const a = "px-3 py-2 text-xs uppercase tracking-[0.2em] text-silver hover:text-champagne";
  return (
    <>
      <nav className="sticky top-0 z-30 flex flex-wrap items-center gap-1 border-b border-white/10 bg-obsidian/95 px-3 backdrop-blur">
        <span className="px-3 font-serif tracking-[0.3em]">SILVZAR</span>
        <Link href="/admin" className={a}>Dashboard</Link>
        <Link href="/admin/products" className={a}>Products</Link>
        <Link href="/admin/orders" className={a}>Orders</Link>
        <form action={signOut} className="ml-auto"><button className={a}>Sign out</button></form>
      </nav>
      <div className="mx-auto max-w-5xl px-4 py-8">{children}</div>
    </>
  );
}
