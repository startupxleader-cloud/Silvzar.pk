import Link from "next/link";
import { requireAdmin } from "@/lib/admin";
import { pkr } from "@/lib/format";

type Row = { id: string; order_number: string; customer_name: string; city: string; total_pkr: number; status: string; payment_status: string; created_at: string };
const filters: [string, string][] = [["", "All"], ["awaiting_verification", "To verify"], ["awaiting_payment", "Unpaid"], ["pending", "New"], ["shipped", "Shipped"]];

export default async function Orders({ searchParams }: { searchParams: Promise<{ f?: string }> }) {
  const { f = "" } = await searchParams;
  const { sb } = await requireAdmin();
  let q = sb.from("orders").select("id,order_number,customer_name,city,total_pkr,status,payment_status,created_at").order("created_at", { ascending: false }).limit(100);
  if (["awaiting_verification", "awaiting_payment"].includes(f)) q = q.eq("payment_status", f);
  else if (["pending", "shipped"].includes(f)) q = q.eq("status", f);
  const rows = ((await q).data ?? []) as Row[];
  return (
    <>
      <h1 className="font-serif text-4xl">Orders</h1>
      <div className="mt-6 flex flex-wrap gap-2">
        {filters.map(([v, l]) => <Link key={v} href={v ? `/admin/orders?f=${v}` : "/admin/orders"} className={`rounded-full border px-4 py-1 text-xs uppercase tracking-widest ${f === v ? "border-champagne text-champagne" : "border-white/15 text-silver"}`}>{l}</Link>)}
      </div>
      <div className="mt-6 space-y-3">
        {rows.length === 0 && <p className="text-silver/60">No orders.</p>}
        {rows.map((o) => (
          <Link key={o.id} href={`/admin/orders/${o.id}`} className="block border border-white/10 p-4 transition hover:border-champagne">
            <div className="flex justify-between gap-3"><span className="font-serif text-lg">{o.order_number}</span><span className="text-champagne">{pkr(o.total_pkr)}</span></div>
            <p className="text-sm text-silver">{o.customer_name} · {o.city}</p>
            <p className="mt-1 text-xs uppercase tracking-widest text-silver/60">{o.status} · {o.payment_status.replace("_", " ")} · {new Date(o.created_at).toLocaleDateString("en-PK", { timeZone: "Asia/Karachi" })}</p>
          </Link>
        ))}
      </div>
    </>
  );
}
