import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/admin";
import { pkr } from "@/lib/format";
import { updateOrder } from "../actions";

const note: Record<string, string> = {
  ok: "Order updated.", pay: "Verify the payment before marking an order shipped or delivered.",
  cancelled: "A cancelled order can't be reopened.", fail: "Could not update the order.",
};
const sel = "h-11 w-full rounded border border-white/15 bg-graphite px-3 text-pearl";

export default async function OrderDetail({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ r?: string }> }) {
  const { id } = await params;
  const { r } = await searchParams;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const { sb } = await requireAdmin();
  const { data: o } = await sb.from("orders").select("*, order_items(name,unit_price_pkr,qty)").eq("id", id).maybeSingle();
  if (!o) notFound();
  const wa = `https://wa.me/92${String(o.phone).slice(1)}`;
  return (
    <>
      <h1 className="font-serif text-4xl">{o.order_number}</h1>
      <p className="mt-1 text-sm text-silver/60">{new Date(o.created_at).toLocaleString("en-PK", { timeZone: "Asia/Karachi" })}</p>
      {r && <p className={`mt-4 rounded p-3 text-sm ${r === "ok" ? "bg-champagne/15 text-champagne" : "bg-red-950/60 text-red-200"}`}>{note[r] ?? ""}</p>}

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="space-y-1 border border-white/10 p-5 text-sm">
          <p className="font-serif text-xl">{o.customer_name}</p>
          <p><a className="text-champagne underline" href={`tel:${o.phone}`}>{o.phone}</a> · <a className="text-champagne underline" href={wa} target="_blank" rel="noopener noreferrer">WhatsApp</a></p>
          {o.email && <p className="text-silver">{o.email}</p>}
          <p className="text-silver">{o.address}, {o.city}</p>
          {o.notes && <p className="pt-2 text-silver/70">Note: {o.notes}</p>}
        </div>
        <div className="space-y-2 border border-white/10 p-5 text-sm">
          {(o.order_items as { name: string; unit_price_pkr: number; qty: number }[]).map((i, k) => <div key={k} className="flex justify-between gap-3"><span>{i.name} × {i.qty}</span><span>{pkr(i.unit_price_pkr * i.qty)}</span></div>)}
          <div className="flex justify-between border-t border-white/10 pt-2 text-silver"><span>Shipping</span><span>{pkr(o.shipping_pkr)}</span></div>
          <div className="flex justify-between font-serif text-xl"><span>Total</span><span>{pkr(o.total_pkr)}</span></div>
        </div>
      </div>

      <div className="mt-6 border border-champagne/40 p-5">
        <p className="text-xs uppercase tracking-[0.3em] text-champagne">Payment reference from customer</p>
        <p className="mt-2 font-serif text-2xl">{o.payment_reference ?? "Not submitted yet"}</p>
        <p className="mt-1 text-sm text-silver/60">Check it against your bank or wallet statement before marking it verified.</p>
      </div>

      <form action={updateOrder} className="mt-6 grid gap-4 border border-white/10 p-5 sm:grid-cols-2">
        <input type="hidden" name="id" value={o.id} />
        <label className="text-xs uppercase tracking-[0.2em] text-silver/70">Payment
          <select name="payment_status" defaultValue={o.payment_status} className={`${sel} mt-1`}>
            <option value="awaiting_payment">Awaiting payment</option><option value="awaiting_verification">Awaiting verification</option>
            <option value="verified">Verified</option><option value="rejected">Rejected</option>
          </select></label>
        <label className="text-xs uppercase tracking-[0.2em] text-silver/70">Order status
          <select name="status" defaultValue={o.status} className={`${sel} mt-1`}>
            <option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option><option value="cancelled">Cancelled (returns stock)</option>
          </select></label>
        <button className="rounded-full bg-silver py-3 text-xs font-medium uppercase tracking-[0.25em] text-obsidian sm:col-span-2">Save changes</button>
      </form>
    </>
  );
}
