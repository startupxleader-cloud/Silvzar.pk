"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/admin";

export async function updateOrder(f: FormData) {
  const { sb } = await requireAdmin();
  const id = String(f.get("id")), status = String(f.get("status")), pay = String(f.get("payment_status"));
  if (!/^[0-9a-f-]{36}$/i.test(id)) redirect("/admin/orders");
  const { error } = await sb.rpc("admin_update_order", { p_id: id, p_status: status, p_payment_status: pay });
  revalidatePath("/admin/orders");
  const code = !error ? "ok" : error.message === "PAYMENT_NOT_VERIFIED" ? "pay" : error.message === "NOT_ALLOWED" ? "cancelled" : "fail";
  if (error) console.error("admin_update_order", error.message);
  redirect(`/admin/orders/${id}?r=${code}`);
}
