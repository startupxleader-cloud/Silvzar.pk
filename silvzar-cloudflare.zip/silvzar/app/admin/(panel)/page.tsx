import Link from "next/link";
import { requireAdmin } from "@/lib/admin";

export default async function Dashboard() {
  const { sb } = await requireAdmin();
  const count = async (q: PromiseLike<{ count: number | null }>) => (await q).count ?? 0;
  const head = { count: "exact" as const, head: true };
  const [verify, pending, drafts, low, products] = await Promise.all([
    count(sb.from("orders").select("id", head).eq("payment_status", "awaiting_verification")),
    count(sb.from("orders").select("id", head).eq("status", "pending")),
    count(sb.from("products").select("id", head).eq("status", "draft")),
    count(sb.from("products").select("id", head).lte("stock", 3)),
    count(sb.from("products").select("id", head)),
  ]);
  const cards: [string, number, string][] = [
    ["Payments to verify", verify, "/admin/orders?f=awaiting_verification"], ["New orders", pending, "/admin/orders?f=pending"],
    ["Drafts", drafts, "/admin/products"], ["Low stock (3 or less)", low, "/admin/products"], ["Products", products, "/admin/products"],
  ];
  return (
    <>
      <h1 className="font-serif text-4xl">Dashboard</h1>
      <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3">
        {cards.map(([t, n, h]) => (
          <Link key={t} href={h} className="border border-white/10 p-5 transition hover:border-champagne">
            <p className="font-serif text-4xl text-champagne">{n}</p><p className="mt-1 text-sm text-silver">{t}</p>
          </Link>
        ))}
      </div>
      <Link href="/admin/products/new" className="mt-8 inline-block rounded-full bg-silver px-8 py-3 text-xs font-medium uppercase tracking-[0.25em] text-obsidian">+ New product</Link>
    </>
  );
}
