"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/admin";

export type ProductInput = { id?: string; name: string; slug: string; description: string; category: string; collection_id: string; price_pkr: number; stock: number; status: string; images: string[] };
export type SaveResult = { ok: true } | { ok: false; error: string };
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const refresh = () => revalidatePath("/", "layout");

export async function saveProduct(i: ProductInput): Promise<SaveResult> {
  const { sb } = await requireAdmin();
  const name = String(i.name ?? "").trim(), slug = String(i.slug ?? "").trim();
  const description = String(i.description ?? "").trim(), category = String(i.category ?? "").trim();
  const price = Number(i.price_pkr), stock = Number(i.stock), status = String(i.status);
  const collection = i.collection_id ? String(i.collection_id) : "";
  const prefix = `https://res.cloudinary.com/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/`;
  const images = (Array.isArray(i.images) ? i.images : []).map(String);

  if (name.length < 1 || name.length > 160) return { ok: false, error: "Enter a product name (up to 160 characters)." };
  if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug) || slug.length > 100) return { ok: false, error: "URL slug: lowercase letters, numbers and hyphens only." };
  if (description.length > 5000) return { ok: false, error: "Description is too long." };
  if (category.length > 60) return { ok: false, error: "Category is too long." };
  if (!Number.isInteger(price) || price < 0 || price > 10_000_000) return { ok: false, error: "Enter a valid price in PKR." };
  if (!Number.isInteger(stock) || stock < 0 || stock > 100_000) return { ok: false, error: "Enter a valid stock quantity." };
  if (status !== "draft" && status !== "published") return { ok: false, error: "Invalid status." };
  if (collection && !UUID.test(collection)) return { ok: false, error: "Invalid collection." };
  if (i.id && !UUID.test(i.id)) return { ok: false, error: "Invalid product." };
  if (images.length > 10 || images.some((u) => !u.startsWith(prefix))) return { ok: false, error: "Images must be uploaded through the uploader (max 10)." };
  if (status === "published" && images.length === 0) return { ok: false, error: "Add at least one photo before publishing." };

  const { error } = await sb.rpc("admin_save_product", {
    p_id: i.id || null,
    p: { slug, name, description, category, collection_id: collection, price_pkr: price, stock, status },
    p_images: images.map((url) => ({ url })),
  });
  if (error) {
    if (error.code === "23505") return { ok: false, error: "That URL slug is already used by another product." };
    console.error("admin_save_product", error.message);
    return { ok: false, error: "Could not save the product." };
  }
  refresh();
  return { ok: true };
}

export async function deleteProduct(id: string): Promise<SaveResult> {
  const { sb } = await requireAdmin();
  if (!UUID.test(id)) return { ok: false, error: "Invalid product." };
  const { error } = await sb.from("products").delete().eq("id", id);
  if (error) { console.error("deleteProduct", error.message); return { ok: false, error: "Could not delete the product." }; }
  refresh();
  return { ok: true };
}

export async function setStock(f: FormData) {
  const { sb } = await requireAdmin();
  const id = String(f.get("id")), stock = Number(f.get("stock"));
  if (UUID.test(id) && Number.isInteger(stock) && stock >= 0 && stock <= 100_000) await sb.from("products").update({ stock }).eq("id", id);
  refresh();
  redirect("/admin/products");
}

export async function togglePublish(f: FormData) {
  const { sb } = await requireAdmin();
  const id = String(f.get("id")), to = String(f.get("to"));
  if (!UUID.test(id) || (to !== "draft" && to !== "published")) redirect("/admin/products");
  if (to === "published") {
    const { count } = await sb.from("product_images").select("id", { count: "exact", head: true }).eq("product_id", id);
    if (!count) redirect("/admin/products?e=photo");
  }
  await sb.from("products").update({ status: to }).eq("id", id);
  refresh();
  redirect("/admin/products");
}
