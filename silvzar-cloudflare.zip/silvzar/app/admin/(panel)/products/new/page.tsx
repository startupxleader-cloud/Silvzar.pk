import ProductForm from "@/components/admin/ProductForm";
import { requireAdmin } from "@/lib/admin";

export default async function NewProduct() {
  const { sb } = await requireAdmin();
  const { data } = await sb.from("collections").select("id,name").order("position");
  return (
    <>
      <h1 className="mb-8 font-serif text-4xl">New product</h1>
      <ProductForm collections={data ?? []} initial={{ name: "", slug: "", description: "", category: "", collection_id: "", price_pkr: 0, stock: 0, status: "draft", images: [] }} />
    </>
  );
}
