import Link from "next/link";
import { requireAdmin } from "@/lib/admin";
import { pkr } from "@/lib/format";
import { setStock, togglePublish } from "./actions";

type Row = { id: string; name: string; price_pkr: number; stock: number; status: string; product_images: { url: string; position: number }[] };

export default async function Products({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  const { e } = await searchParams;
  const { sb } = await requireAdmin();
  const { data } = await sb.from("products").select("id,name,price_pkr,stock,status,product_images(url,position)").order("created_at", { ascending: false }).limit(200);
  const rows = (data ?? []) as Row[];
  return (
    <>
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-4xl">Products</h1>
        <Link href="/admin/products/new" className="rounded-full bg-silver px-6 py-2 text-xs font-medium uppercase tracking-[0.2em] text-obsidian">+ New</Link>
      </div>
      {e === "photo" && <p className="mt-4 rounded bg-red-950/60 p-3 text-sm text-red-200">Add at least one photo before publishing.</p>}
      <div className="mt-8 space-y-3">
        {rows.length === 0 && <p className="text-silver/60">No products yet.</p>}
        {rows.map((p) => {
          const img = [...p.product_images].sort((a, b) => a.position - b.position)[0]?.url;
          return (
            <div key={p.id} className="flex flex-wrap items-center gap-4 border border-white/10 p-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <div className="h-16 w-16 shrink-0 overflow-hidden bg-graphite">{img && <img src={img} alt="" className="h-full w-full object-cover" />}</div>
              <div className="min-w-0 flex-1">
                <Link href={`/admin/products/${p.id}`} className="font-serif text-xl hover:text-champagne">{p.name}</Link>
                <p className="text-sm text-silver">{pkr(p.price_pkr)} · <span className={p.status === "published" ? "text-champagne" : "text-silver/60"}>{p.status}</span></p>
              </div>
              <form action={setStock} className="flex items-center gap-2">
                <input type="hidden" name="id" value={p.id} />
                <input name="stock" type="number" min={0} max={100000} defaultValue={p.stock} aria-label="Stock" className={`h-10 w-20 rounded border bg-graphite px-2 text-center ${p.stock <= 3 ? "border-red-400/60" : "border-white/15"}`} />
                <button className="h-10 rounded border border-white/20 px-3 text-xs uppercase tracking-widest">Save</button>
              </form>
              <form action={togglePublish}>
                <input type="hidden" name="id" value={p.id} />
                <input type="hidden" name="to" value={p.status === "published" ? "draft" : "published"} />
                <button className="h-10 rounded border border-champagne/50 px-3 text-xs uppercase tracking-widest text-champagne">{p.status === "published" ? "Unpublish" : "Publish"}</button>
              </form>
            </div>
          );
        })}
      </div>
    </>
  );
}
