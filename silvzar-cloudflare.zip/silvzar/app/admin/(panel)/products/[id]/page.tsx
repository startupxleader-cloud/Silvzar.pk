import { notFound } from "next/navigation";
import ProductForm from "@/components/admin/ProductForm";
import { requireAdmin } from "@/lib/admin";

export default async function EditProduct({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const { sb } = await requireAdmin();
  const [{ data: p }, { data: cols }] = await Promise.all([
    sb.from("products").select("id,name,slug,description,category,collection_id,price_pkr,stock,status,product_images(url,position)").eq("id", id).maybeSingle(),
    sb.from("collections").select("id,name").order("position"),
  ]);
  if (!p) notFound();
  const images = [...p.product_images].sort((a, b) => a.position - b.position).map((i) => i.url);
  return (
    <>
      <h1 className="mb-8 font-serif text-4xl">Edit product</h1>
      <ProductForm collections={cols ?? []} initial={{ id: p.id, name: p.name, slug: p.slug, description: p.description ?? "", category: p.category ?? "", collection_id: p.collection_id ?? "", price_pkr: p.price_pkr, stock: p.stock, status: p.status, images }} />
    </>
  );
}
