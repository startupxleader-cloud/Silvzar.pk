"use server";
import { db } from "@/lib/data";

export type PlaceResult = { ok: true; number: string; token: string } | { ok: false; error: string };
type Input = { name: string; phone: string; email: string; city: string; address: string; notes: string; items: { id: string; qty: number }[] };

const msg: Record<string, string> = {
  "INVALID:name": "Please enter your full name.",
  "INVALID:phone": "Enter a valid Pakistani mobile number, e.g. 0300 1234567.",
  "INVALID:address": "Please enter your full delivery address.",
  "INVALID:city": "Please enter your city.",
  "INVALID:email": "That email address looks invalid.",
  "INVALID:notes": "Order notes are too long.",
  "INVALID:method": "Please choose a payment method.",
  "INVALID:items": "Your cart looks invalid. Please refresh and try again.",
  UNAVAILABLE: "An item in your cart is no longer available.",
  RATE_LIMIT: "Too many orders from this number. Please try again later.",
};

// Only product ids and quantities are accepted from the browser. Prices, stock and totals are computed in the database.
export async function placeOrder(input: Input): Promise<PlaceResult> {
  const items = Array.isArray(input?.items) ? input.items.slice(0, 20).map((i) => ({ id: String(i?.id), qty: Number(i?.qty) })) : [];
  const { data, error } = await db().rpc("place_order", {
    p_name: String(input?.name ?? ""), p_phone: String(input?.phone ?? ""), p_email: String(input?.email ?? ""),
    p_address: String(input?.address ?? ""), p_city: String(input?.city ?? ""), p_notes: String(input?.notes ?? ""),
    p_method: "bank_transfer", p_items: items,
  });
  if (error) {
    const m = error.message ?? "";
    if (m.startsWith("OUT_OF_STOCK:")) return { ok: false, error: `${m.slice(13)} has limited stock. Please reduce the quantity.` };
    if (msg[m]) return { ok: false, error: msg[m] };
    console.error("place_order", m);
    return { ok: false, error: "We couldn't place your order. Please try again." };
  }
  return { ok: true, number: data.order_number, token: data.token };
}
