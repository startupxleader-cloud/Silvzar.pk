import type { Metadata } from "next";
import CheckoutForm from "@/components/CheckoutForm";
import { getSettings } from "@/lib/data";

export const metadata: Metadata = { title: "Checkout", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const s = await getSettings();
  return (
    <div className="mx-auto max-w-5xl px-5 pb-24 pt-28">
      <h1 className="text-center font-serif text-5xl text-pearl">Checkout</h1>
      <CheckoutForm shipping={s.shipping_flat_pkr} freeOver={s.free_shipping_over_pkr} />
    </div>
  );
}
