// next/image loader: Cloudinary resizes and converts photos (f_auto, q_auto) so phone-sized originals are never sent to shoppers.
export default function cloudinaryLoader({ src, width, quality }: { src: string; width: number; quality?: number }) {
  const marker = "/image/upload/";
  if (!src.startsWith("https://res.cloudinary.com/") || !src.includes(marker)) return src;
  return src.replace(marker, `${marker}f_auto,q_${quality ?? "auto"},w_${width},c_limit/`);
}
