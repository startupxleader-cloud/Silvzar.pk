import { createClient } from "@supabase/supabase-js";

// Anon key only: RLS limits this to published products. The service-role key is never used here.
export const db = () =>
  createClient(process.env.NEXT_PUBLIC_SUPABASE_URL ?? "", process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "", {
    auth: { persistSession: false },
  });

export type Img = { url: string; position: number };
export type Product = {
  id: string; slug: string; name: string; description: string | null; category: string | null;
  price_pkr: number; stock: number; product_images: Img[];
};
export type Collection = { id: string; slug: string; name: string; description: string | null };
export type Sort = "new" | "price_asc" | "price_desc";
export type Settings = { shipping_flat_pkr: number; free_shipping_over_pkr: number | null; payment_instructions: string };

const cols = "id,slug,name,description,category,price_pkr,stock,product_images(url,position)";
const sortImgs = (p: Product): Product => ({ ...p, product_images: [...p.product_images].sort((a, b) => a.position - b.position) });

export async function getCollections(): Promise<Collection[]> {
  const { data, error } = await db().from("collections").select("id,slug,name,description").order("position");
  if (error) { console.error("getCollections", error.message); return []; }
  return data ?? [];
}

export async function getCategories(): Promise<string[]> {
  const { data } = await db().from("products").select("category").eq("status", "published");
  return [...new Set((data ?? []).map((r) => r.category).filter((c): c is string => !!c))].sort();
}

export async function getProducts(o: { collection?: string; q?: string; category?: string; sort?: Sort; limit?: number } = {}): Promise<Product[]> {
  const { collection, q, category, sort = "new", limit = 48 } = o;
  let query = db().from("products").select(cols).eq("status", "published").limit(limit);
  query = sort === "price_asc" ? query.order("price_pkr", { ascending: true })
        : sort === "price_desc" ? query.order("price_pkr", { ascending: false })
        : query.order("created_at", { ascending: false });
  if (category) query = query.eq("category", category);
  const term = (q ?? "").replace(/[^\p{L}\p{N} -]/gu, "").trim().slice(0, 60); // strip filter-syntax characters
  if (term) query = query.or(`name.ilike.%${term}%,category.ilike.%${term}%,description.ilike.%${term}%`);
  if (collection && collection !== "all") {
    const { data: c } = await db().from("collections").select("id").eq("slug", collection).maybeSingle();
    if (!c) return [];
    query = query.eq("collection_id", c.id);
  }
  const { data, error } = await query;
  if (error) { console.error("getProducts", error.message); return []; }
  return ((data ?? []) as unknown as Product[]).map(sortImgs);
}

export async function getProduct(slug: string): Promise<Product | null> {
  const { data, error } = await db().from("products").select(cols).eq("slug", slug).eq("status", "published").maybeSingle();
  if (error) { console.error("getProduct", error.message); return null; }
  return data ? sortImgs(data as unknown as Product) : null;
}

export async function getSettings(): Promise<Settings> {
  const { data } = await db().from("store_settings").select("shipping_flat_pkr,free_shipping_over_pkr,payment_instructions").eq("id", 1).maybeSingle();
  return data ?? { shipping_flat_pkr: 250, free_shipping_over_pkr: null, payment_instructions: "Payment details will be shared by the store." };
}

export type OrderView = {
  order_number: string; status: string; payment_method: "bank_transfer"; payment_status: string;
  payment_reference: string | null; customer_name: string; city: string; address: string;
  subtotal_pkr: number; shipping_pkr: number; total_pkr: number; created_at: string;
  items: { name: string; unit_price_pkr: number; qty: number }[];
};
export async function getOrder(number: string, token: string): Promise<OrderView | null> {
  if (!/^SZ-\d{6}-\d{4,}$/.test(number) || !/^[0-9a-f]{64}$/.test(token)) return null;
  const { data, error } = await db().rpc("get_order", { p_order_number: number, p_token: token });
  if (error || !data) return null;
  return data as OrderView;
}
