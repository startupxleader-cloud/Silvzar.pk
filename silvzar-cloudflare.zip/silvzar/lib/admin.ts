import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

// Call at the top of every admin page and action. getUser() re-verifies the session with Supabase; is_admin() checks the allowlist.
export async function requireAdmin() {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/admin/login");
  const { data: ok } = await sb.rpc("is_admin");
  if (ok !== true) redirect("/admin/login?e=1");
  return { sb, user };
}
