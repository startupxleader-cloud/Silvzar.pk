"use client";
import { usePathname } from "next/navigation";

// Hides storefront header/footer/floating buttons on admin pages.
export default function Chrome({ children }: { children: React.ReactNode }) {
  return usePathname().startsWith("/admin") ? null : <>{children}</>;
}
