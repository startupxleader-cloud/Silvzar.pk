"use client";
import { useCart } from "./CartProvider";
import type { Product } from "@/lib/data";

export default function AddToCart({ p }: { p: Product }) {
  const { add } = useCart();
  const out = p.stock <= 0;
  return (
    <button disabled={out}
      onClick={() => add({ id: p.id, slug: p.slug, name: p.name, price: p.price_pkr, image: p.product_images[0]?.url ?? null, max: p.stock })}
      className="w-full rounded-full bg-gradient-to-r from-silver via-pearl to-silver py-4 text-sm font-medium uppercase tracking-[0.3em] text-obsidian transition active:scale-[.98] disabled:opacity-40">
      {out ? "Sold out" : "Add to cart"}
    </button>
  );
}
