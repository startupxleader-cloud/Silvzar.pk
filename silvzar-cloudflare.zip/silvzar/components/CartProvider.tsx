"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

// Display-only snapshot. Checkout (Phase 2) re-reads price and stock from the database on the server.
export type CartItem = { id: string; slug: string; name: string; price: number; image: string | null; qty: number; max: number };
type Ctx = {
  items: CartItem[]; count: number; subtotal: number; open: boolean; setOpen: (v: boolean) => void;
  add: (i: Omit<CartItem, "qty">) => void; setQty: (id: string, qty: number) => void; remove: (id: string) => void; clear: () => void;
};
const CartCtx = createContext<Ctx | null>(null);
export const useCart = () => { const c = useContext(CartCtx); if (!c) throw new Error("useCart outside provider"); return c; };

export default function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [open, setOpen] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try { const raw = localStorage.getItem("silvzar-cart"); if (raw) setItems(JSON.parse(raw)); } catch {}
    setReady(true);
  }, []);
  useEffect(() => { if (ready) try { localStorage.setItem("silvzar-cart", JSON.stringify(items)); } catch {} }, [items, ready]);

  const add = useCallback((i: Omit<CartItem, "qty">) => {
    setItems((cur) => {
      const f = cur.find((x) => x.id === i.id);
      if (f) return cur.map((x) => (x.id === i.id ? { ...x, qty: Math.min(x.qty + 1, i.max) } : x));
      return [...cur, { ...i, qty: 1 }];
    });
    setOpen(true);
  }, []);
  const setQty = useCallback((id: string, qty: number) =>
    setItems((cur) => cur.flatMap((x) => (x.id !== id ? [x] : qty <= 0 ? [] : [{ ...x, qty: Math.min(qty, x.max) }]))), []);
  const remove = useCallback((id: string) => setItems((cur) => cur.filter((x) => x.id !== id)), []);
  const clear = useCallback(() => setItems([]), []);

  const value = useMemo(() => ({
    items, open, setOpen, add, setQty, remove, clear,
    count: items.reduce((n, i) => n + i.qty, 0),
    subtotal: items.reduce((n, i) => n + i.qty * i.price, 0),
  }), [items, open, add, setQty, remove, clear]);

  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
