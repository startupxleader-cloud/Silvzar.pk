"use client";
import Link from "next/link";
import { useState } from "react";

const links = [
  { href: "/collections/all", label: "All Jewellery" },
  { href: "/collections/exclusive", label: "Exclusive Collection" },
  { href: "/collections/stainless-steel", label: "Stainless Steel" },
  { href: "/#story", label: "Our Story" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-40 border-b border-white/5 bg-obsidian/60 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <button aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)} className="group flex h-10 w-10 flex-col items-start justify-center gap-[6px]">
          <span className={`h-px w-6 bg-silver transition ${open ? "translate-y-[7px] rotate-45" : ""}`} />
          <span className={`h-px w-4 bg-silver transition group-hover:w-6 ${open ? "opacity-0" : ""}`} />
          <span className={`h-px w-6 bg-silver transition ${open ? "-translate-y-[7px] -rotate-45" : ""}`} />
        </button>
        <Link href="/" className="font-serif text-2xl tracking-[0.45em] text-pearl">SILVZAR</Link>
        <span className="w-10" />
      </div>
      <nav className={`fixed inset-0 top-16 flex flex-col items-center justify-center gap-8 bg-obsidian/95 backdrop-blur-xl transition duration-500 ${open ? "opacity-100" : "pointer-events-none opacity-0"}`}>
        {links.map((l) => (
          <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="font-serif text-3xl text-silver transition hover:text-champagne">{l.label}</Link>
        ))}
      </nav>
    </header>
  );
}
