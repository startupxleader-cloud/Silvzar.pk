"use client";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "./CartProvider";
import { pkr } from "@/lib/format";

const wa = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER;

export default function FloatingDock() {
  const { items, count, subtotal, open, setOpen, setQty, remove } = useCart();
  const [dial, setDial] = useState(false);
  const [showTop, setShowTop] = useState(false);
  useEffect(() => {
    const f = () => setShowTop(window.scrollY > 600);
    f(); window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);

  const btn = "flex h-12 w-12 items-center justify-center rounded-full border border-white/10 bg-graphite/90 text-silver shadow-lg shadow-black/50 backdrop-blur transition hover:border-champagne hover:text-champagne active:scale-95";
  return (
    <>
      <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-3">
        <div className={`flex flex-col items-end gap-3 transition duration-300 ${dial ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}>
          {showTop && <button aria-label="Back to top" className={btn} onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>↑</button>}
          {wa && <a aria-label="WhatsApp" className={btn} href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">WA</a>}
          <button aria-label="Open cart" className={`${btn} relative`} onClick={() => { setOpen(true); setDial(false); }}>
            ◇{count > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-champagne px-1 text-[11px] font-semibold text-obsidian">{count}</span>}
          </button>
        </div>
        <button aria-label="Quick actions" aria-expanded={dial} onClick={() => setDial(!dial)}
          className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-pearl to-silver text-xl text-obsidian shadow-xl shadow-black/60 transition active:scale-95">
          <span className={`transition-transform duration-300 ${dial ? "rotate-45" : ""}`}>+</span>
          {count > 0 && !dial && <span className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-champagne ring-2 ring-obsidian" />}
        </button>
      </div>

      <div className={`fixed inset-0 z-50 transition ${open ? "" : "pointer-events-none"}`}>
        <div onClick={() => setOpen(false)} className={`absolute inset-0 bg-black/70 transition duration-500 ${open ? "opacity-100" : "opacity-0"}`} />
        <aside className={`absolute right-0 top-0 flex h-full w-full max-w-md flex-col border-l border-white/10 bg-obsidian transition duration-500 ${open ? "translate-x-0" : "translate-x-full"}`}>
          <div className="flex items-center justify-between border-b border-white/10 p-5">
            <h2 className="font-serif text-2xl">Your Cart</h2>
            <button aria-label="Close cart" onClick={() => setOpen(false)} className="text-2xl text-silver">×</button>
          </div>
          <div className="flex-1 space-y-5 overflow-y-auto p-5">
            {items.length === 0 && <p className="text-silver/70">Your cart is empty.</p>}
            {items.map((i) => (
              <div key={i.id} className="flex gap-4">
                <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded bg-graphite">
                  {i.image && <Image src={i.image} alt={i.name} fill sizes="80px" className="object-cover" />}
                </div>
                <div className="flex-1">
                  <p className="font-serif text-lg leading-tight">{i.name}</p>
                  <p className="text-sm text-champagne">{pkr(i.price)}</p>
                  <div className="mt-2 flex items-center gap-3 text-sm">
                    <button className="h-7 w-7 rounded border border-white/15" onClick={() => setQty(i.id, i.qty - 1)}>−</button>
                    <span>{i.qty}</span>
                    <button className="h-7 w-7 rounded border border-white/15 disabled:opacity-30" disabled={i.qty >= i.max} onClick={() => setQty(i.id, i.qty + 1)}>+</button>
                    <button className="ml-auto text-xs text-silver/60 underline" onClick={() => remove(i.id)}>Remove</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="space-y-3 border-t border-white/10 p-5">
            <div className="flex justify-between"><span className="text-silver">Subtotal</span><span className="font-serif text-xl">{pkr(subtotal)}</span></div>
            <Link href="/checkout" onClick={() => setOpen(false)} aria-disabled={items.length === 0} className={`block w-full rounded-full bg-gradient-to-r from-silver via-pearl to-silver py-3 text-center text-sm font-medium uppercase tracking-[0.25em] text-obsidian ${items.length === 0 ? "pointer-events-none opacity-40" : ""}`}>Checkout</Link>
          </div>
        </aside>
      </div>
    </>
  );
}
