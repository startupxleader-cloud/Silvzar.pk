"use client";
import { useActionState } from "react";
import { submitReference, type RefState } from "@/app/order/[number]/actions";

export default function PaymentRefForm({ number, token }: { number: string; token: string }) {
  const [state, action, pending] = useActionState<RefState, FormData>(submitReference, null);
  return (
    <form action={action} className="mt-4 space-y-3">
      <input type="hidden" name="number" value={number} />
      <input type="hidden" name="token" value={token} />
      <input name="reference" required minLength={4} maxLength={60} placeholder="Transaction ID / reference" className="w-full rounded border border-white/15 bg-graphite px-4 py-3 text-pearl outline-none focus:border-champagne" />
      <button disabled={pending} className="rounded-full bg-silver px-8 py-3 text-xs font-medium uppercase tracking-[0.25em] text-obsidian disabled:opacity-50">{pending ? "Sending…" : "Submit reference"}</button>
      {state && <p role="status" className={`text-sm ${state.ok ? "text-champagne" : "text-red-300"}`}>{state.message}</p>}
    </form>
  );
}
