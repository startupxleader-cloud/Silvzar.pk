"use client";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { deleteProduct, saveProduct } from "@/app/admin/(panel)/products/actions";

export type FormProduct = { id?: string; name: string; slug: string; description: string; category: string; collection_id: string; price_pkr: number; stock: number; status: "draft" | "published"; images: string[] };
const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);

export default function ProductForm({ initial, collections }: { initial: FormProduct; collections: { id: string; name: string }[] }) {
  const router = useRouter();
  const [f, setF] = useState(initial);
  const [slugTouched, setSlugTouched] = useState(!!initial.id);
  const [uploading, setUploading] = useState(false);
  const [msg, setMsg] = useState("");
  const [pending, start] = useTransition();
  const set = <K extends keyof FormProduct>(k: K, v: FormProduct[K]) => setF((s) => ({ ...s, [k]: v }));
  const field = "w-full rounded border border-white/15 bg-graphite px-4 py-3 text-pearl outline-none focus:border-champagne";
  const label = "mb-1 block text-xs uppercase tracking-[0.2em] text-silver/70";

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setMsg(""); setUploading(true);
    try {
      for (const file of Array.from(files)) {
        if (!file.type.startsWith("image/") || file.size > 10 * 1024 * 1024) { setMsg("Images only, up to 10 MB each."); continue; }
        const sig = await fetch("/api/admin/cloudinary-sign", { method: "POST" }).then((r) => r.json());
        if (!sig.signature) throw new Error(sig.error || "Upload is not available.");
        const fd = new FormData();
        fd.append("file", file); fd.append("api_key", sig.key); fd.append("timestamp", String(sig.timestamp));
        fd.append("signature", sig.signature); fd.append("folder", sig.folder); fd.append("allowed_formats", sig.allowed);
        const res = await fetch(`https://api.cloudinary.com/v1_1/${sig.cloud}/image/upload`, { method: "POST", body: fd }).then((r) => r.json());
        if (!res.secure_url) throw new Error(res.error?.message || "Upload failed.");
        setF((s) => (s.images.length >= 10 ? s : { ...s, images: [...s.images, res.secure_url] }));
      }
    } catch (e) { setMsg(e instanceof Error ? e.message : "Upload failed."); }
    setUploading(false);
  }
  const move = (i: number, d: number) => setF((s) => { const a = [...s.images]; const j = i + d; if (j < 0 || j >= a.length) return s; [a[i], a[j]] = [a[j], a[i]]; return { ...s, images: a }; });
  const save = (status: "draft" | "published") => { setMsg(""); start(async () => {
    const r = await saveProduct({ ...f, status });
    if (!r.ok) return setMsg(r.error);
    router.push("/admin/products"); router.refresh();
  }); };
  const del = () => { if (!initial.id || !confirm("Delete this product permanently?")) return; start(async () => {
    const r = await deleteProduct(initial.id!);
    if (!r.ok) return setMsg(r.error);
    router.push("/admin/products"); router.refresh();
  }); };

  return (
    <div className="space-y-5">
      <div>
        <span className={label}>Photos (first one is the cover)</span>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-5">
          {f.images.map((u, i) => (
            <div key={u} className="space-y-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={u} alt="" className="aspect-square w-full object-cover" />
              <div className="flex justify-between text-xs">
                <button type="button" onClick={() => move(i, -1)} className="px-2 py-1">←</button>
                <button type="button" onClick={() => set("images", f.images.filter((x) => x !== u))} className="px-2 py-1 text-red-300">✕</button>
                <button type="button" onClick={() => move(i, 1)} className="px-2 py-1">→</button>
              </div>
            </div>
          ))}
          {f.images.length < 10 && (
            <label className="flex aspect-square cursor-pointer items-center justify-center border border-dashed border-white/30 text-center text-xs text-silver">
              {uploading ? "Uploading…" : "+ Add photos"}
              <input type="file" accept="image/*" multiple className="hidden" disabled={uploading} onChange={(e) => { upload(e.target.files); e.target.value = ""; }} />
            </label>
          )}
        </div>
      </div>
      <div><label className={label}>Name</label><input className={field} maxLength={160} value={f.name} onChange={(e) => { set("name", e.target.value); if (!slugTouched) set("slug", slugify(e.target.value)); }} /></div>
      <div><label className={label}>URL slug</label><input className={field} maxLength={100} value={f.slug} onChange={(e) => { setSlugTouched(true); set("slug", slugify(e.target.value)); }} /></div>
      <div><label className={label}>Description</label><textarea className={field} rows={5} maxLength={5000} value={f.description} onChange={(e) => set("description", e.target.value)} /></div>
      <div className="grid grid-cols-2 gap-4">
        <div><label className={label}>Category</label><input className={field} maxLength={60} placeholder="Necklace" value={f.category} onChange={(e) => set("category", e.target.value)} /></div>
        <div><label className={label}>Collection</label>
          <select className={field} value={f.collection_id} onChange={(e) => set("collection_id", e.target.value)}>
            <option value="">None</option>{collections.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select></div>
        <div><label className={label}>Price (PKR)</label><input className={field} type="number" inputMode="numeric" min={0} value={f.price_pkr} onChange={(e) => set("price_pkr", Number(e.target.value))} /></div>
        <div><label className={label}>Stock</label><input className={field} type="number" inputMode="numeric" min={0} value={f.stock} onChange={(e) => set("stock", Number(e.target.value))} /></div>
      </div>
      {msg && <p role="alert" className="rounded bg-red-950/60 p-3 text-sm text-red-200">{msg}</p>}
      <div className="flex flex-wrap gap-3 pt-2">
        <button disabled={pending || uploading} onClick={() => save("draft")} className="rounded-full border border-silver/40 px-8 py-3 text-xs uppercase tracking-[0.25em] disabled:opacity-50">Save as draft</button>
        <button disabled={pending || uploading} onClick={() => save("published")} className="rounded-full bg-silver px-8 py-3 text-xs font-medium uppercase tracking-[0.25em] text-obsidian disabled:opacity-50">Publish</button>
        {initial.id && <button disabled={pending} onClick={del} className="ml-auto text-xs uppercase tracking-[0.2em] text-red-300">Delete</button>}
      </div>
      <p className="text-xs text-silver/50">Nothing goes live until you press Publish.</p>
    </div>
  );
}
