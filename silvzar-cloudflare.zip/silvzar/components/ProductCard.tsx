import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/lib/data";
import { pkr } from "@/lib/format";

export default function ProductCard({ p }: { p: Product }) {
  const img = p.product_images[0]?.url;
  return (
    <Link href={`/products/${p.slug}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden rounded-sm bg-graphite">
        {img ? (
          <Image src={img} alt={p.name} fill sizes="(max-width:768px) 50vw, 25vw" className="object-cover transition duration-700 group-hover:scale-105" />
        ) : (
          <div className="flex h-full items-center justify-center bg-gradient-to-br from-graphite to-obsidian font-serif text-sm tracking-[0.4em] text-silver/30">SILVZAR</div>
        )}
        {p.stock === 0 && <span className="absolute left-3 top-3 bg-obsidian/80 px-2 py-1 text-[10px] uppercase tracking-widest text-silver">Sold out</span>}
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian/70 via-transparent opacity-0 transition duration-500 group-hover:opacity-100" />
      </div>
      <div className="mt-3 flex items-baseline justify-between gap-3">
        <h3 className="font-serif text-lg leading-tight text-pearl">{p.name}</h3>
        <span className="shrink-0 text-sm text-champagne">{pkr(p.price_pkr)}</span>
      </div>
    </Link>
  );
}
