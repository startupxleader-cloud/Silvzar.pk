"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { placeOrder } from "@/app/checkout/actions";
import { useCart } from "./CartProvider";
import { pkr } from "@/lib/format";

export default function CheckoutForm({ shipping, freeOver }: { shipping: number; freeOver: number | null }) {
  const { items, subtotal, clear } = useCart();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [err, setErr] = useState("");
  const est = freeOver !== null && subtotal >= freeOver ? 0 : shipping;
  const field = "w-full rounded border border-white/15 bg-graphite px-4 py-3 text-pearl outline-none focus:border-champagne";

  if (items.length === 0)
    return (
      <div className="mt-16 text-center">
        <p className="text-silver/70">Your cart is empty.</p>
        <Link href="/collections/all" className="mt-6 inline-block text-xs uppercase tracking-[0.3em] text-champagne">Browse jewellery</Link>
      </div>
    );

  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setErr("");
    start(async () => {
      const r = await placeOrder({
        name: String(f.get("name")), phone: String(f.get("phone")), email: String(f.get("email")), city: String(f.get("city")),
        address: String(f.get("address")), notes: String(f.get("notes")),
        items: items.map((i) => ({ id: i.id, qty: i.qty })),
      });
      if (!r.ok) return setErr(r.error);
      clear();
      router.push(`/order/${r.number}?t=${r.token}`);
    });
  }

  return (
    <form onSubmit={submit} className="mt-12 grid gap-10 md:grid-cols-[1.2fr_1fr]">
      <div className="space-y-4">
        <input name="name" required minLength={2} maxLength={100} placeholder="Full name" autoComplete="name" className={field} />
        <input name="phone" required inputMode="tel" placeholder="Mobile (03XX XXXXXXX)" autoComplete="tel" className={field} />
        <input name="email" type="email" maxLength={120} placeholder="Email (optional)" autoComplete="email" className={field} />
        <input name="city" required minLength={2} maxLength={60} placeholder="City" autoComplete="address-level2" className={field} />
        <textarea name="address" required minLength={5} maxLength={300} rows={3} placeholder="Full delivery address" autoComplete="street-address" className={field} />
        <textarea name="notes" maxLength={500} rows={2} placeholder="Order notes (optional)" className={field} />
        <div className="rounded border border-champagne/40 p-4 text-sm">
          <p className="text-xs uppercase tracking-[0.3em] text-champagne">Payment</p>
          <p className="mt-2 text-pearl">Bank / wallet transfer</p>
          <p className="mt-1 text-silver/70">After you place the order you'll see our payment details. Send the amount, then submit your transaction reference. We verify it manually before shipping.</p>
        </div>
      </div>

      <aside className="h-fit space-y-4 border border-white/10 bg-graphite/40 p-6">
        {items.map((i) => (
          <div key={i.id} className="flex justify-between gap-4 text-sm"><span>{i.name} × {i.qty}</span><span className="text-silver">{pkr(i.price * i.qty)}</span></div>
        ))}
        <div className="flex justify-between border-t border-white/10 pt-4 text-sm"><span className="text-silver">Subtotal</span><span>{pkr(subtotal)}</span></div>
        <div className="flex justify-between text-sm"><span className="text-silver">Shipping</span><span>{est === 0 ? "Free" : pkr(est)}</span></div>
        <div className="flex justify-between font-serif text-2xl"><span>Total</span><span>{pkr(subtotal + est)}</span></div>
        <p className="text-xs text-silver/50">Final prices and stock are confirmed by our server when you place the order.</p>
        {err && <p role="alert" className="rounded bg-red-950/60 p-3 text-sm text-red-200">{err}</p>}
        <button disabled={pending} className="w-full rounded-full bg-gradient-to-r from-silver via-pearl to-silver py-4 text-sm font-medium uppercase tracking-[0.3em] text-obsidian disabled:opacity-50">
          {pending ? "Placing order…" : "Place order"}
        </button>
      </aside>
    </form>
  );
}
