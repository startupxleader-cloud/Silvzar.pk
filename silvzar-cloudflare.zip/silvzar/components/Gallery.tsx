"use client";
import Image from "next/image";
import { useState } from "react";
import type { Img } from "@/lib/data";

export default function Gallery({ images, name }: { images: Img[]; name: string }) {
  const [i, setI] = useState(0);
  if (images.length === 0)
    return <div className="flex aspect-square items-center justify-center bg-graphite font-serif tracking-[0.4em] text-silver/30">SILVZAR</div>;
  return (
    <div>
      <div className="relative aspect-square overflow-hidden bg-graphite">
        <Image key={images[i].url} src={images[i].url} alt={name} fill priority sizes="(max-width:768px) 100vw, 50vw" className="object-cover" />
      </div>
      {images.length > 1 && (
        <div className="mt-3 grid grid-cols-5 gap-2">
          {images.map((m, k) => (
            <button key={m.url} aria-label={`Image ${k + 1}`} onClick={() => setI(k)} className={`relative aspect-square overflow-hidden border ${k === i ? "border-champagne" : "border-white/10"}`}>
              <Image src={m.url} alt="" fill sizes="80px" className="object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
