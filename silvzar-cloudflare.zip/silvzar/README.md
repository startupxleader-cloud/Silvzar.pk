# SILVZAR: Phase 1

1. Supabase: create a project, open SQL Editor, paste `supabase/schema.sql`, Run.
2. Copy `.env.example` to `.env.local` and fill the Supabase URL and anon key (Project Settings > API).
3. Local: `npm install && npm run dev` then open http://localhost:3000
4. Check before deploying: `npm run typecheck && npm run build`
5. Deploy: push to GitHub, import in Vercel, add the same env vars, deploy. Then add silvzar.com in Vercel > Domains and set the DNS records it shows in Cloudflare.

## Phase 2 (checkout, COD, manual payment verification, search)
- Schema is already applied to your Supabase project (migrations `phase1_catalogue`, `phase2_orders_checkout`). No new env vars.
- Edit bank/wallet details and shipping in Supabase SQL Editor:
  `update store_settings set payment_instructions = 'Bank: ...\nAccount title: ...\nIBAN: ...', shipping_flat_pkr = 250, free_shipping_over_pkr = 5000 where id = 1;`
- Payment is bank/wallet transfer only (cash on delivery removed). Orders are created only by the database function `place_order`, which re-reads prices and stock and decrements stock atomically.

## Phase 3 (private admin)
- Cloudinary: add NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET to .env.local and Vercel (secret is server-only).
- Create your admin login: Supabase > Authentication > Users > Add user (email + password, tick auto-confirm). Then in SQL Editor:
  `insert into admins (user_id) select id from auth.users where email = 'YOUR-EMAIL';`
- Open /admin/login. Only users in the `admins` table get in; the database enforces this too.

## Deploy on Cloudflare Workers (OpenNext)
Files: `wrangler.jsonc`, `open-next.config.ts`, `.env.production` (public values), `lib/cloudinary-loader.ts`.
1. Put this project in a GitHub repo. Edit `.env.production`: set NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME (and NEXT_PUBLIC_WHATSAPP_NUMBER).
2. Cloudflare dashboard > Workers & Pages > Create > Import a repository. Project name: silvzar.
   Build command: `npx opennextjs-cloudflare build`   Deploy command: `npx opennextjs-cloudflare deploy`
3. Project > Settings > Variables and Secrets > add as **Secret**: CLOUDINARY_API_KEY and CLOUDINARY_API_SECRET.
4. After the first successful deploy: Settings > Domains & Routes > Add > Custom domain: `silvzar.com`, then `www.silvzar.com`.
   Delete any old A/CNAME records for those names in DNS first (e.g. leftovers from Vercel); Cloudflare creates the new ones itself.
