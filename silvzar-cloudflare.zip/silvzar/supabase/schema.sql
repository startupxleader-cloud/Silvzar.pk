-- SILVZAR Phase 1 schema. Run in Supabase > SQL Editor.
create table if not exists collections (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text,
  position int not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null check (char_length(name) between 1 and 160),
  description text,
  category text,
  collection_id uuid references collections(id) on delete set null,
  price_pkr integer not null check (price_pkr >= 0),
  stock integer not null default 0 check (stock >= 0),
  status text not null default 'draft' check (status in ('draft','published')),
  created_at timestamptz not null default now()
);
create table if not exists product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  url text not null,
  position int not null default 0
);
create index if not exists products_status_idx on products(status, created_at desc);
create index if not exists images_product_idx on product_images(product_id, position);

alter table collections enable row level security;
alter table products enable row level security;
alter table product_images enable row level security;

-- Public (anon) read-only access to published catalogue data. No write policies exist:
-- all writes will go through the authenticated admin in a later phase.
create policy "public read collections" on collections for select using (true);
create policy "public read published products" on products for select using (status = 'published');
create policy "public read images of published products" on product_images for select
  using (exists (select 1 from products p where p.id = product_id and p.status = 'published'));

-- Sample data (replace later from the admin dashboard).
insert into collections (slug, name, description, position) values
  ('exclusive', 'Exclusive Collection', 'Signature pieces, limited and considered.', 1),
  ('stainless-steel', 'Stainless Steel', 'Tarnish-resistant everyday jewellery.', 2)
on conflict (slug) do nothing;
insert into products (slug, name, description, category, collection_id, price_pkr, stock, status)
select 'infinity-heart-pendant', 'Infinity Heart Pendant', 'A silver-tone infinity heart on a fine chain.', 'Necklace', id, 3499, 12, 'published' from collections where slug = 'exclusive'
on conflict (slug) do nothing;
insert into products (slug, name, description, category, collection_id, price_pkr, stock, status)
select 'rose-cz-pendant', 'Rose CZ Pendant', 'A rose set with pink cubic zirconia.', 'Necklace', id, 3999, 8, 'published' from collections where slug = 'exclusive'
on conflict (slug) do nothing;
